package com.nt.dao;

import com.nt.bo.JobSeekerBO;

public interface JobSeekerDAO {
   public  int insert(JobSeekerBO bo)throws Exception;
}
