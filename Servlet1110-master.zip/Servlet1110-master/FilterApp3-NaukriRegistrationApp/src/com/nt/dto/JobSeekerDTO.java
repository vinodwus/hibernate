package com.nt.dto;

import java.io.Serializable;

public class JobSeekerDTO implements Serializable {
	private String name;
	private int age;
	private String addrs;
	private String skill;
	private int experience;
	private int expSal;
	private String preLoc;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddrs() {
		return addrs;
	}
	public void setAddrs(String addrs) {
		this.addrs = addrs;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public int getExpSal() {
		return expSal;
	}
	public void setExpSal(int expSal) {
		this.expSal = expSal;
	}
	public String getPreLoc() {
		return preLoc;
	}
	public void setPreLoc(String preLoc) {
		this.preLoc = preLoc;
	}

}
