package com.nt.service;

import com.nt.dto.JobSeekerDTO;

public interface JobSeekerService {
	public String register(JobSeekerDTO dto)throws Exception;

}
