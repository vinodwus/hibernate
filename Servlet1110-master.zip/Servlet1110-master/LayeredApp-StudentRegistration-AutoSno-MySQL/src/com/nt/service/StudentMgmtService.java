package com.nt.service;

import com.nt.dto.StudentDTO;

public interface StudentMgmtService {
	public String register(StudentDTO dto)throws Exception;

}
